"""Selected finite display adapter. Projection cannot alter model state/topology."""
import json, math, hashlib, textwrap
import numpy as np
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
P=Path('output'); plan=json.loads((P/'plan.json').read_text())
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
MONO='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
def font(n,b=False):return ImageFont.truetype(BOLD if b else FONT,n)
def point(a):return list(map(float,a.split(','))) if isinstance(a,str) else [a['x'],a['y'],a['z']]
def proj(a,cx,cy,s):
 x,y,z=point(a);return (cx+(x-z)*.72*s,cy+(-y+.42*(x+z))*s)
def dashed(d,a,b,col,width=1):
 n=max(1,int(math.dist(a,b)/5))
 for i in range(0,n,2):
  j=min(i+1,n);d.line((a[0]+(b[0]-a[0])*i/n,a[1]+(b[1]-a[1])*i/n,a[0]+(b[0]-a[0])*j/n,a[1]+(b[1]-a[1])*j/n),fill=col,width=width)
def text(d,xy,s,n=18,color='#abb5c9',bold=False):d.text(xy,s,font=font(n,bold),fill=color)
def cloud(d,addresses,cx,cy,s,color,r=3):
 for a in addresses:
  x,y=proj(a,cx,cy,s);d.ellipse((x-r,y-r,x+r,y+r),fill=color)
class RecordingDraw:
 def __init__(self,image):self.draw=ImageDraw.Draw(image);self.ops=[]
 def __getattr__(self,name):
  def call(*args,**kwargs):
   def integer_coords(v):return tuple(integer_coords(x) for x in v) if isinstance(v,(tuple,list)) else round(v)
   args=(integer_coords(args[0]),*args[1:])
   if name=='text':bbox=self.draw.textbbox(args[0],args[1],font=kwargs['font'])
   elif name in ('line','ellipse','rounded_rectangle'):
    pts=args[0]
    if isinstance(pts[0],tuple):xs=[p[0] for p in pts];ys=[p[1] for p in pts]
    else:xs=pts[0::2];ys=pts[1::2]
    pad=kwargs.get('width',1)+2;bbox=(min(xs)-pad,min(ys)-pad,max(xs)+pad,max(ys)+pad)
   else:raise ValueError(name)
   self.ops.append((name,args,kwargs,bbox))
   return getattr(self.draw,name)(*args,**kwargs)
  return call

def shifted(args,dx,dy):
 p=args[0]
 if isinstance(p[0],tuple):p=tuple((x-dx,y-dy) for x,y in p)
 else:p=tuple(v-(dx if i%2==0 else dy) for i,v in enumerate(p))
 return (p,*args[1:])

def signature(ops):
 # Font values are explicitly represented; no process-specific object addresses.
 return repr([(n,a,{k:('font',v.path,v.size) if k=='font' else v for k,v in kw.items()}) for n,a,kw,b in ops])

prior=None;prior_sigs={};delta_reports=[]
def wrapped(d,xy,s,n=18,width=75,color='#c1cddd',gap=27):
 for index,line in enumerate(textwrap.wrap(s,width=width)):text(d,(xy[0],xy[1]+index*gap),line,n,color)
for scene_index,act in enumerate(plan['acts']+[plan['acts'][-1]]):
 state=act['state'];entry=state['entry'];container=state['container'];im=Image.new('RGB',(1280,720),'#0b101d');d=RecordingDraw(im)
 text(d,(38,22),'FRACTURE  /  AN ADDED VIDEO PATTERN',27,'#eef5ff',True)
 text(d,(39,64),f'EXISTING CONTAINER  scene @ {container["inventory_binary_address"]}   •   map and container records retained',16,'#f5cf86')
 d.rounded_rectangle((30,104,870,565),radius=15,fill='#111b2b',outline='#24364c')
 text(d,(51,122),'IS',26,'#52e2cb',True);text(d,(98,130),f'PATTERN TICK {act["act"]:02}   |   {entry["id"]} @ {entry["inventory_binary_address"]}',17)
 wrapped(d,(51,184),entry['term'],25,50,'#edf5ff',34)
 wrapped(d,(51,262),entry['support'],19,69,'#bacbdd',30)
 text(d,(51,365),'EXISTING CAUSAL PARENTS',13,'#84aaa9',True)
 for i,parent in enumerate(state['parents']):
  x=61+i*246;d.rounded_rectangle((x,404,x+221,446),radius=7,fill='#16333d',outline='#49767c')
  text(d,(x+12,414),parent['id'],14,'#81e9cf');d.line((x+110,446,x+110,470),fill='#4a6f79',width=1)
 text(d,(51,482),'Read-only source relations; this display adds no map nodes or world law',15,'#bfcddd')
 text(d,(51,528),f'SOURCE  {entry["sources"][0]["path"]}',14,'#8db9be')
 for y,label,st,col in [(104,'WAS',act['wasState'],'#bd9cf8'),(342,'NEXT',act['nextState'],'#ffcf72')]:
  d.rounded_rectangle((888,y,1250,y+222),radius=14,fill='#111b2b',outline='#24364c')
  text(d,(906,y+16),label,21,col,True)
  if st:
   e=st['entry'];text(d,(906,y+57),e['id'],19,col,True);text(d,(906,y+89),'existing address '+e['inventory_binary_address'],13)
   wrapped(d,(906,y+123),e['term'],16,29,'#bacbdd',24)
  else:wrapped(d,(906,y+78),'No prior pattern frame' if label=='WAS' else 'No further frame in this bounded output',17,27)
 text(d,(39,586),f'RETURN  pattern tick {act["act"]} → complete frame {act["act"]}   |   original world Act unchanged',18,'#e8eef9',True)
 text(d,(39,617),f'MAP SHA-256  {plan["sourceHashes"]["sources/FRACTURE-FIELD-INVENTORY.json"][:24]}   •   added pattern hash {act["stateHash"][:16]}',15)
 text(d,(39,649),'Retain the frame → update changed pixels only → verify full coverage → next pattern tick',16,'#52e2cb')
 text(d,(39,681),'Layout, resolution and playback duration are output-format choices. The existing map remains authoritative.',13,'#a4aec1')
 # Real delta renderer: unchanged tiles never rasterize. The full image above is an independent test oracle only.
 out=prior.copy() if prior is not None else Image.new('RGB',(1280,720),'#0b101d');sigs={};dirty=[];reused_tiles=0
 for top in range(0,720,64):
  for left in range(0,1280,64):
   right,bottom=min(left+64,1280),min(top+64,720)
   ops=[op for op in d.ops if op[3][0]<right and op[3][2]>=left and op[3][1]<bottom and op[3][3]>=top]
   key=(left,top);sig=signature(ops);sigs[key]=sig
   if prior is not None and prior_sigs.get(key)==sig:reused_tiles+=1;continue
   tile=Image.new('RGB',(right-left,bottom-top),'#0b101d');td=ImageDraw.Draw(tile)
   for name,args,kwargs,bbox in ops:getattr(td,name)(*shifted(args,left,top),**kwargs)
   out.paste(tile,(left,top));dirty.append([left,top,right,bottom])
 if out.tobytes()!=im.tobytes():
  out.save(P/'delta-debug.png');im.save(P/'oracle-debug.png')
 assert out.tobytes()==im.tobytes(),f'Delta raster differs from independent full baseline at Act {act["act"]}'
 a=np.asarray(out);old=np.asarray(prior) if prior is not None else np.zeros_like(a)
 changed=np.any(a!=old,axis=2) if prior is not None else np.ones((720,1280),dtype=bool)
 indices=np.flatnonzero(changed).astype('<u4');
 if scene_index==len(plan['acts']):
  assert not dirty and not len(indices) and reused_tiles==240
  (P/'no-change-test.json').write_text(json.dumps({'passed':True,'rasterizedTiles':0,'writtenPixels':0,'reusedPixels':921600,'bitIdentical':True},indent=2));continue
 (P/f'act-{act["act"]:02}.patch').write_bytes(indices.tobytes())
 if prior is not None:assert np.array_equal(a[~changed],old[~changed])
 delta_reports.append({'act':act['act'],'dirtyRegions':dirty,'rasterizedTiles':len(dirty),'reusedTiles':reused_tiles,'changedPixels':len(indices),'reusedPixels':1280*720-len(indices),'fullBaselineEqual':True,'unchangedPixelsBitIdentical':True})
 out.save(P/f'act-{act["act"]:02}.png');(P/f'act-{act["act"]:02}.rgb').write_bytes(out.tobytes());prior=out;prior_sigs=sigs
(P/'delta-report.json').write_text(json.dumps(delta_reports,indent=2))
print('Rendered 8 source-driven whole-state rasters')
