import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {spawn} from 'node:child_process';
import {derivePatternStates} from './pattern-adapter.mjs';
import {createAddressedDraw,mayAdvanceAfterDraw} from './src/model/addressed-draw.ts';

const plan=JSON.parse(fs.readFileSync('output/plan.json'));const {width,height,fps,holdFrames}=plan.selected;
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');const recomputed=derivePatternStates();
const replay=process.argv.includes('--replay');const receipts=[];let lastHash=null;let logicalAct=0;const output=Buffer.alloc(width*height*3);const deltaReports=JSON.parse(fs.readFileSync("output/delta-report.json"));
let encoder,encoderDone;
if(!replay){encoder=spawn('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',`${width}x${height}`,'-framerate','2/3','-i','pipe:0','-an','-c:v','libx264','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart','output/fracture-proof.mp4'],{stdio:['pipe','ignore','inherit']});encoderDone=new Promise((resolve,reject)=>{encoder.on('error',reject);encoder.on('exit',code=>code===0?resolve():reject(Error(`Encoder exit ${code}`)))});}
for(const act of plan.acts){
 assert.equal(act.act,logicalAct,'no skipped logical ticks');
 assert.equal(sha(JSON.stringify(recomputed[logicalAct])),act.stateHash,'state recomputed from source constraints');
 assert.deepEqual(recomputed[logicalAct].state,act.state);
 assert.equal(act.state.worldActChanged,false,'added pattern cannot advance original world Act');
 assert.equal(act.state.binding.containerId,'scene');
 const source=fs.readFileSync(`output/act-${String(act.act).padStart(2,'0')}.rgb`);assert.equal(source.length,width*height*3);
 for(let held=0;held<holdFrames;held++){
  const draw=createAddressedDraw(width,height);const patchBytes=fs.readFileSync(`output/act-${String(act.act).padStart(2,'0')}.patch`);const patch=new Uint32Array(patchBytes.buffer,patchBytes.byteOffset,patchBytes.byteLength/4);let patchCursor=0;const before=Buffer.from(output);assert(!mayAdvanceAfterDraw(draw.receipt(),false));
  let expectedIndex=0;
  while(!draw.receipt().complete){draw.assign(8192,(index,x,y)=>{assert.equal(index,expectedIndex++);assert.equal(index,y*width+x);const b=index*3;if(patchCursor<patch.length&&patch[patchCursor]===index){output[b]=source[b];output[b+1]=source[b+1];output[b+2]=source[b+2];patchCursor++;}else {assert.equal(output[b],before[b]);assert.equal(output[b+1],before[b+1]);assert.equal(output[b+2],before[b+2]);}});}
  const completed=draw.receipt();assert.equal(expectedIndex,width*height);assert(output.equals(source));assert.equal(patchCursor,patch.length);assert(!mayAdvanceAfterDraw(completed,false));
  // Receipt means a complete RGB frame accepted by the encoder transport, not proof of a physical display.
  if(!replay)await new Promise((resolve,reject)=>encoder.stdin.write(output,error=>error?reject(error):resolve()));
  assert(mayAdvanceAfterDraw(completed,true));
  const body={frame:receipts.length,act:logicalAct,held,was:act.wasState,is:act.state,next:act.nextState,stateHash:act.stateHash,proposedStateHash:act.nextHash,draw:completed,delta:{changedPixels:patch.length,reusedPixels:width*height-patch.length,coveredPixels:width*height,rasterizedTiles:deltaReports[act.act].rasterizedTiles,reusedTiles:deltaReports[act.act].reusedTiles,fullBaselineEqual:true,unchangedPixelsBitIdentical:true},logicalTick:logicalAct,transportAccepted:true,rawRGBSha256:sha(output),previousReceiptSha256:lastHash,advanceAfterThisFrame:held===holdFrames-1&&act.act<plan.acts.length-1};
  lastHash=sha(JSON.stringify(body));receipts.push({...body,receiptSha256:lastHash});
 }
 if(act.act<plan.acts.length-1)logicalAct++;
}
if(!replay){encoder.stdin.end();await encoderDone;fs.writeFileSync('output/frame-receipts.json',JSON.stringify(receipts,null,2));}
else assert.deepEqual(receipts,JSON.parse(fs.readFileSync('output/frame-receipts.json')),'independent replay raw frames and receipt chain');
console.log(JSON.stringify({mode:replay?'replay':'encode',frames:receipts.length,coveredPixels:receipts.length*width*height,writtenPixels:receipts.reduce((n,r)=>n+r.delta.changedPixels,0),reusedPixels:receipts.reduce((n,r)=>n+r.delta.reusedPixels,0),tickFrameBijection:receipts.every((r,i)=>r.logicalTick===i&&r.frame===i),finalAct:logicalAct,finalState:recomputed[logicalAct],finalReceipt:lastHash,replayMatches:replay},null,2));
