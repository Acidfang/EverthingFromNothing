import fs from 'node:fs';import {deriveVideoPattern} from './src/model/video-pattern.ts';
export function derivePatternStates(){return deriveVideoPattern(JSON.parse(fs.readFileSync('sources/FRACTURE-FIELD-INVENTORY.json','utf8')));}
